package com.example.tp;

public class ApceException extends Exception {
    public ApceException(String message) {
        super(message);
    }
}
